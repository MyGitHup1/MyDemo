export { default as Slider } from './Slider'
export { default as Navs } from './Navs'
export { default as Mains } from './Mains'
